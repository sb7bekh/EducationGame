SB7-TEAM — ta'limiy o'yinlar sayti

Fayllar:
- index.html — butun sayt (HTML + CSS + JS)
- logo.png — logotip
- polka.mp3 — Andijon polkasi musiqasi

Ishga tushirish: index.html ni brauzerda oching yoki papkani hostingga yuklang.
Login/parol: YARASHOV / YARASHOV (index.html ichidagi login() funksiyasida).
